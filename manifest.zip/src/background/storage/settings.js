// ==================================================================================================
// SETTINGS MANAGEMENT
// ==================================================================================================

import { PROVIDERS } from '../constants.js';

export class SettingsManager {
  static async get(keys) {
    if (typeof browser !== 'undefined' && browser.storage?.local) {
      return browser.storage.local.get(keys);
    }
    return new Promise(resolve => chrome.storage.local.get(keys, resolve));
  }

  static async getLyricsSettings() {
    return this.get({
      'lyricsProviderOrder': 'kpoe,unison,lrclib',
      'lyricsSourceOrder': 'apple,lyricsplus,qq,musixmatch,musixmatch-word',
      'customKpoeUrl': '',
      'cacheStrategy': 'aggressive',
      'preferUnisonVideo': false
    });
  }

  static async getTranslationSettings() {
    return this.get({
      'translationProvider': PROVIDERS.GOOGLE,
      'romanizationProvider': PROVIDERS.GOOGLE,
      'geminiApiKey': '',
      'geminiModel': 'gemini-pro',
      'geminiRomanizationModel': 'gemini-pro',
      'overrideTranslateTarget': false,
      'customTranslateTarget': '',
      'overrideGeminiPrompt': false,
      'customGeminiPrompt': '',
      'overrideGeminiRomanizePrompt': false,
      'customGeminiRomanizePrompt': '',
      'openRouterApiKey': '',
      'openRouterModel': 'google/gemini-2.0-flash-001',
      'deeplApiKey': ''
    });
  }
}
